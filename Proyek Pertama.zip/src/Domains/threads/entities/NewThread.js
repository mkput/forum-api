class NewThread {
  constructor({ title, body, owner }) {
    if (!title || !body || !owner) {
      throw new Error('NEW_THREAD.NOT_CONTAIN_NEEDED_PROPERTY');
    }

    if (
      typeof title !== 'string' ||
      typeof body !== 'string' ||
      typeof owner !== 'string'
    ) {
      throw new Error('NEW_THREAD.NOT_MEET_DATA_SPECIFICATION');
    }

    if (title.length > 50) {
      throw new Error('NEW_THREAD.LIMIT_CHAR');
    }

    this.title = title;
    this.body = body;
    this.owner = owner;
  }
}

module.exports = NewThread;
